<?php

interface P2P_Field {
	function get_title();
	function render( $p2p_id, $item );
}

